package summerCamp_Pavithra;

public class CheckPalindrome {
	
	public void verifyStrings(String s1){
		
		char[] charArr = s1.toCharArray();
		
		String revString = "";
		
		
		for(int i = s1.length()-1; i>=0; i--){
			revString=revString + charArr[i];
		}
		
		boolean result = revString.equalsIgnoreCase(s1);
		
		if(result)
			System.out.println("The String "+s1+" is Palindrome");
		else
			System.out.println("The String "+s1+" is not Palindrome");
		
		
	}

	public static void main(String[] args) {
		
		CheckPalindrome q6 = new CheckPalindrome();
		
		q6.verifyStrings("abc");
		q6.verifyStrings("liril");

	}

}
