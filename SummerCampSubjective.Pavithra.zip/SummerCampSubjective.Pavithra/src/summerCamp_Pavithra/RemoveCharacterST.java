package summerCamp_Pavithra;

public class RemoveCharacterST {

	public void removecharacter() {

		String str = "REST ASSURED";
		String result = str.replace("ST", "");
		System.out.println(result);
	}
	
	public static void compare2Strings(){
		
		String s1 = "Selenium";
		String s2 = "Java";		
		System.out.println(s1.compareTo(s2));
		
	}

	public static void main(String[] args) {
		
		RemoveCharacterST r = new RemoveCharacterST();
		
		r.removecharacter();
		compare2Strings();
		

	}

}
