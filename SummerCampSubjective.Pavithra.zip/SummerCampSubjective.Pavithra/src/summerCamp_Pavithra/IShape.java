package summerCamp_Pavithra;

public interface IShape {
	
	public abstract void displayShape();

}
