package summerCamp_Pavithra;

public class Question8 implements IShape {
	
	@Override
	public void displayShape() {
		System.out.println("I am circle");
		
	}
	
	public void add(int a, int b){
		
		System.out.println(a+b);
	}
	
	public void add(String a, String b){
		
		System.out.println(a+b);
	}

	public static void main(String[] args) {
		
		Question8 q8 = new Question8();
		
		q8.displayShape();
		q8.add(1, 6);
		q8.add("Java", " Training");
		

	}

}
