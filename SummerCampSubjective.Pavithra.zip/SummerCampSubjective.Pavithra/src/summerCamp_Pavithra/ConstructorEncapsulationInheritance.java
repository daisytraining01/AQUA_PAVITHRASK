package summerCamp_Pavithra;

public class ConstructorEncapsulationInheritance extends Enroll{
	
	private String PhoneNumber;
	
	
	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	int rollNum;
	String Name;
	
	public ConstructorEncapsulationInheritance(int r, String n){
		rollNum = r;
		Name = n;
		
	}

	public static void main(String[] args) {
		
		ConstructorEncapsulationInheritance student1 = new ConstructorEncapsulationInheritance(101, "Sameer");
		ConstructorEncapsulationInheritance student2 = new ConstructorEncapsulationInheritance(102, "Sumaa");
		
				
		student1.setPhoneNumber("9876543210");
		String s1Number = student1.getPhoneNumber();
		
		student2.setPhoneNumber("9876563210");
		String s2Number = student2.getPhoneNumber();
		
		student1.display(student1.Name,s1Number);		
		student2.display(student2.Name,s2Number);		

	}

	

}

class Enroll{
	
	public void display(String name, String number){
		System.out.println("Enrollment Successful for "+name+" with "+number);
	}
	
}
