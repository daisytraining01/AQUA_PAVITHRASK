package summerCamp_Pavithra;

import java.util.*;
import java.util.Map.Entry;

public class Question7 {

	public static void main(String[] args) {
		
		Map<String, String> hm = new HashMap<String, String>();
		
		hm.put("Key 1", "TestVal1");
		hm.put("Key 2", "TestVal2");
		hm.put("Key 3", "TestVal1");
		hm.put("Key 4", "TestVal2");
		hm.put("Key 5", "TestVal2");
		hm.put("Key 6", "TestVal3");
		
		for(Map.Entry m:hm.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		 } 
		
		System.out.println("====After removing=====");
		
		Set<String> hs = new HashSet<String>();
		
		Map<String, String> hmNew = new HashMap<String, String>();
		
		for(Entry<String, String> e: hm.entrySet()){
			
			if(hs.add(e.getValue()))
				hmNew.put(e.getKey(), e.getValue());
		}
		
		for(Map.Entry m:hmNew.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      } 
		
		//System.out.println(hmNew);
		
		

	}

}
